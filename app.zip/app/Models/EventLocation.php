<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EventLocation extends Model
{
    protected $table = "event_locations";

    public $timestamps = false;
}
