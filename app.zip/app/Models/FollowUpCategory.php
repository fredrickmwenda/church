<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FollowUpCategory extends Model
{
    protected $table = "follow_up_categories";

    public $timestamps = false;
}
