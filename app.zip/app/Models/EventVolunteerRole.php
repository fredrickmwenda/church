<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EventVolunteerRole extends Model
{
    protected $table = "event_volunteer_roles";

    public $timestamps = false;
}
