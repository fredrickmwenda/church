<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PayrollTemplateMeta extends Model
{
    protected $table = "payroll_template_meta";
    public $timestamps = false;


}
