<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SmsGateway extends Model
{
    protected $table = "sms_gateways";

    public $timestamps = false;
}
